@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0CyberVaultRelease.ps1"
